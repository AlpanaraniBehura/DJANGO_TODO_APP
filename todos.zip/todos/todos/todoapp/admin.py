from django.contrib import admin
from .models import Mytodo

admin.site.register(Mytodo)
# Register your models here.
